#!/usr/bin/env bash
# Migra el repo de "una carpeta por TP" a "organizado por función".
# Uso (desde cualquier lugar del repo):
#     bash migrate.sh                 # usa el alu.v de TP2 como canónico
#     ALU_SOURCE=tp1 bash migrate.sh  # usa el alu.v de TP1
#
# - Hace un tag `pre-refactor` para poder volver atrás.
# - Trabaja en una rama nueva (refactor/estructura).
# - Usa `git mv` en un commit aparte para que Git siga el historial de cada archivo.
set -euo pipefail

cd "$(git rev-parse --show-toplevel)"

ALU_SOURCE="${ALU_SOURCE:-tp2}"

# ---------- Chequeos previos ----------
for d in TP1_ALU TP2_UART; do
  [[ -d "$d" ]] || { echo "ERROR: no existe $d (¿ya migraste?)"; exit 1; }
done

if [[ -n "$(git status --porcelain -- TP1_ALU TP2_UART)" ]]; then
  echo "ERROR: hay cambios sin commitear en TP1_ALU/TP2_UART. Commiteá o stasheá antes."
  exit 1
fi

# ---------- Red de seguridad ----------
git tag pre-refactor 2>/dev/null || echo "(el tag pre-refactor ya existía, se conserva)"
git checkout -b refactor/estructura

# ---------- Estructura destino ----------
mkdir -p rtl/common rtl/peripherals/uart rtl/debug rtl/pipeline rtl/control rtl/memory \
         ip \
         tb/unit tb/integration sw \
         fpga/tp1_alu fpga/tp2_uart fpga/riscv_basys3 \
         tools/assembler tools/debugger \
         docs/spec docs/decisiones docs/timing docs/diagramas docs/tps scripts

# Git no versiona carpetas vacías: placeholders para lo que viene.
for d in rtl/debug rtl/pipeline rtl/control rtl/memory ip fpga/riscv_basys3 tb/integration sw \
         tools/assembler docs/spec docs/decisiones docs/timing docs/diagramas docs/tps; do
  touch "$d/.gitkeep"
done

# ---------- alu.v duplicado ----------
if diff -q TP1_ALU/rtl/alu.v TP2_UART/rtl/alu.v >/dev/null; then
  echo "alu.v es idéntico en TP1 y TP2."
  git mv TP2_UART/rtl/alu.v rtl/common/alu.v
  git rm -q TP1_ALU/rtl/alu.v
else
  echo "======================================================================"
  echo "AVISO: alu.v DIFIERE entre TP1 y TP2. Diferencias (TP1 -> TP2):"
  diff -u TP1_ALU/rtl/alu.v TP2_UART/rtl/alu.v || true
  echo "======================================================================"
  echo "Se usa la versión de: $ALU_SOURCE  (cambiable con ALU_SOURCE=tp1|tp2)"
  echo "La otra queda como docs/tps/alu_<tp>.v.orig para que la reconcilies."
  if [[ "$ALU_SOURCE" == "tp1" ]]; then
    git mv TP1_ALU/rtl/alu.v rtl/common/alu.v
    git mv TP2_UART/rtl/alu.v docs/tps/alu_tp2.v.orig
  else
    git mv TP2_UART/rtl/alu.v rtl/common/alu.v
    git mv TP1_ALU/rtl/alu.v docs/tps/alu_tp1.v.orig
  fi
fi

# ---------- RTL reutilizable ----------
git mv TP1_ALU/rtl/debouncer.v rtl/common/debouncer.v

for f in baud_generator flag_buff intf_circ uart_fsm uart_rx uart_rx_datapath uart_tx uart_tx_datapath; do
  git mv "TP2_UART/rtl/$f.v" "rtl/peripherals/uart/$f.v"
done

# ---------- Diseños sintetizables (top + constraints por TP) ----------
git mv TP1_ALU/rtl/top.v            fpga/tp1_alu/top.v
git mv TP1_ALU/constraints/basys3.xdc fpga/tp1_alu/basys3.xdc

git mv TP2_UART/rtl/top.v           fpga/tp2_uart/top.v
git mv TP2_UART/rtl/alu_top.v       fpga/tp2_uart/alu_top.v
git mv TP2_UART/constraints/basys3.xdc fpga/tp2_uart/basys3.xdc

# ---------- Testbenches ----------
git mv TP1_ALU/tb/alu_tb.v  tb/unit/alu_tb.v
git mv TP2_UART/tb/uart_tb.v tb/unit/uart_tb.v

# ---------- Herramientas de host ----------
git mv TP2_UART/serial_comm.py tools/debugger/serial_comm.py

# ---------- Limpieza de carpetas vacías ----------
rm -rf TP1_ALU TP2_UART

# ---------- .gitignore: agregar lo que falte ----------
touch .gitignore
for pat in '*.vcd' '*.vvp' '*.wdb' '__pycache__/' '.venv/'; do
  grep -qxF "$pat" .gitignore || echo "$pat" >> .gitignore
done

# ---------- Commit 1: solo movimientos (los renames quedan detectados) ----------
# (git mv / git rm ya dejaron todo en el índice; README, .gitignore y .gitkeep
#  quedan para el segundo commit a propósito)
git commit -q -m "refactor: reorganizar repositorio por función (solo movimientos)

TP1_ALU/ y TP2_UART/ pasan a:
  rtl/common, rtl/peripherals/uart, fpga/<diseño>, tb/unit, tools/debugger"

echo
echo "Listo el commit de movimientos. Ahora copiá el README, scripts/ y .github/"
echo "del kit y hacé el segundo commit:"
echo "    git add -A && git commit -m 'chore: agregar README, script de proyecto Vivado y plantilla de PR'"
echo
echo "Verificá que el historial se conserva:  git log --follow rtl/peripherals/uart/uart_tx.v"
